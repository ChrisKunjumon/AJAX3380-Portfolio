const express = require('express');

const bodyParser = require('body-parser');
const fs = require('fs');
const { json } = require('body-parser');
const app = express();
const data = require('./data.json');

app.use(bodyParser.urlencoded({ extended: true}));
app.use("/static", express.static("public"));
app.use(express.static(__dirname + 'public'));

app.use(express.static('public'));
;
app.set('view engine', 'pug');

app.get('/index', (req, res) => {
    res.render('index',{data:data.projects});
});
app.get('/about', (req, res) => {
    res.render('about');
});

app.get('/project/:id', (req, res) => {
    res.render('project', {projectId:req.params.id,tech:req.params.technologies,data:data.projects});
});
 

app.listen(3000, function() {
    console.log('Our port number is going on');
});